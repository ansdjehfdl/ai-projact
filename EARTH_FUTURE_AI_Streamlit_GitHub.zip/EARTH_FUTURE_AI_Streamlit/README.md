# EARTH FUTURE AI

Streamlit 앱으로 해수면 변화, 전 지구 CO2 연평균 농도, FAO 지역별 기온 변화 참고 지표를 분석하고 3개 회귀 알고리즘의 과거 검증 성능과 미래 추세를 비교합니다.

## GitHub 저장소 구조

```text
EARTH_FUTURE_AI/
├── app.py
├── requirements.txt
└── data/
    └── earth_environment.csv
```

## 실행 방법

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Community Cloud 배포

1. 이 폴더의 파일을 GitHub 저장소 최상위에 업로드합니다.
2. `data/earth_environment.csv` 경로가 유지되는지 확인합니다.
3. Streamlit Community Cloud에서 저장소를 연결합니다.
4. Main file path에 `app.py`를 입력하고 배포합니다.

## 데이터 주의사항

- 산림 면적과 대기 오염은 현재 버전에서 제외했습니다.
- 결측값은 임의로 0 처리하거나 보간하지 않습니다.
- 기온 열은 FAO 지역별 보고값의 단순 평균이며 공식 전 지구 평균기온이 아닙니다.
- 장기 외삽 결과는 환경 변화의 확정적 예측이 아니라 단순 추세 시나리오입니다.
- Random Forest 및 Gradient Boosting은 관측 범위를 벗어난 미래 외삽에 적합하지 않을 수 있습니다.
